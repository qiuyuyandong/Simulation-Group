"""Run in Blender --background --factory-startup --python this_file.py."""
import ast
import copy
import hashlib
import importlib
import json
import math
import struct
import sys
import tempfile
import shutil
import zipfile
from pathlib import Path

import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy_extras.object_utils import world_to_camera_view

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT.parent / '_compat_check' / 'tree_realism_20261014'
OUTPUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT.parent / 'extension/spacetree-master/src'))
plugin = importlib.import_module('add_mesh_space_tree')
plugin.register()


def run_scene(case, changes=None, fruit='a', root=ROOT):
    path = root / 'space_tree_scene_gen.py'
    code = ast.parse(path.read_text(encoding='utf-8'))
    extra = changes or ''
    body = []
    for node in code.body:
        if isinstance(node, ast.Assign):
            target = ast.unparse(node.targets[0])
            if target == 'fruit_type':
                node.value = ast.Constant(fruit)
            elif target == 'OUTPUT_DIR':
                node.value = ast.Call(ast.Name('Path', ast.Load()), [ast.Constant(str(OUTPUT / case))], [])
            elif target == 'SETTINGS' and isinstance(node.value, ast.Dict):
                body.extend([node, *ast.parse(extra).body])
                continue
        body.append(node)
    code.body = body
    scope = {'__file__': str(path), '__name__': '__main__'}
    exec(compile(ast.fix_missing_locations(code), str(path), 'exec'), scope)
    return scope


def bvh_for(obj):
    evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
    mesh = evaluated.to_mesh()
    try:
        mesh.calc_loop_triangles()
        return BVHTree.FromPolygons([v.co for v in mesh.vertices],
                                   [tuple(t.vertices) for t in mesh.loop_triangles], all_triangles=True)
    finally:
        evaluated.to_mesh_clear()


def inspect_tree(scope):
    result, settings = scope['result'], scope['SETTINGS']
    tree = result['trunk']
    points, parents, radii = (result[key] for key in ('points', 'parents', 'radii'))
    assert parents[0] is None and all(type(p) is int and 0 <= p < i for i, p in enumerate(parents) if i)
    assert all(radii[i] <= radii[p] + 1e-8 for i, p in enumerate(parents) if p is not None)
    assert len(tree.data.vertices) == len(points) and not tree.particle_systems
    assert [m.type for m in tree.modifiers] == ['SKIN', 'SUBSURF']
    shape = settings['shape']
    assert max(p.z for p in points) > shape['height_m'] * 0.80
    assert max(p.z for p in points) <= shape['height_m'] + 0.01
    assert max(max(p.x for p in points)-min(p.x for p in points),
               max(p.y for p in points)-min(p.y for p in points)) > shape['crown_width_m'] * 0.75
    z = shape['bare_trunk_height_m'] / 2
    i = next(i for i in range(1, len(points)) if points[i].z >= z)
    center = points[i-1].lerp(points[i], (z-points[i-1].z)/(points[i].z-points[i-1].z))
    bvh = bvh_for(tree)
    distances = []
    for axis in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0)):
        hit, normal, face, distance = bvh.ray_cast(center, Vector(axis), 1)
        assert hit is not None
        distances.append(distance)
    measured_diameter = sum(distances) / 2
    assert abs(measured_diameter / shape['trunk_diameter_m'] - 1) < 0.025
    leaf_emitter, fruit_emitter = result['leaf_emitter'], result['fruit_emitter']
    assert not leaf_emitter.show_instancer_for_render and not fruit_emitter.show_instancer_for_render
    assert all(v.co.z >= shape['bare_trunk_height_m'] for v in leaf_emitter.data.vertices)
    leaf_surface = bvh_for(leaf_emitter)
    data = {'leaf': [], 'fruit': []}
    leaf_roots = [set() for _ in settings['leaves']['assets']]
    for instance in bpy.context.evaluated_depsgraph_get().object_instances:
        if not instance.is_instance or not instance.particle_system:
            continue
        source = instance.object.original
        kind = 'leaf' if source.get('tree_role') == 'leaf_template' else 'fruit'
        matrix = instance.matrix_world.copy()
        anchor = matrix.translation.copy()
        scale = matrix.to_scale().x
        assert anchor.z >= shape['bare_trunk_height_m'] - 0.001
        closest, normal, index, distance = bvh.find_nearest(anchor)
        assert distance < 0.0002, f'{kind} attachment is floating: {distance}'
        axis = (matrix.to_3x3() @ Vector((0, 0, 1) if kind == 'leaf' else (1, 0, 0))).normalized()
        angle = math.degrees(math.acos(min(1, abs(axis.z))))
        if kind == 'leaf':
            low, high = settings['leaves']['length_m']
            assert low - 1e-5 <= scale <= high + 1e-5
            nearest, outward, face, distance = leaf_surface.find_nearest(anchor)
            growth_axis = (matrix.to_3x3() @ Vector((1, 0, 0))).normalized()
            # Particle normals interpolate across curved faces; outward need not be perpendicular.
            assert growth_axis.dot(outward) > 0.5, 'Leaf points into its supporting branch'
            system_index = next(i for i, ps in enumerate(leaf_emitter.particle_systems)
                                if ps.name == instance.particle_system.name)
            leaf_roots[system_index].add(tuple(round(v, 6) for v in anchor))
            data[kind].append({'anchor': list(anchor), 'angle': angle, 'size': scale})
        else:
            low, high = settings['fruits']['diameter_m']
            assert low - 1e-5 <= scale <= high + 1e-5
            body_center = matrix @ Vector(source['body_center'])
            radius = scale * source['body_radius']
            nearest, outward, face, clearance = bvh.find_nearest(body_center)
            assert clearance >= radius + 0.0001, 'Fruit body intersects the tree'
            assert body_center.z - radius > 0, 'Fruit body crosses the ground'
            assert body_center.z < anchor.z, 'Fruit does not hang below its stem'
            assert angle < 9, 'Fruit tilt exceeds the natural upright range'
            for other in data[kind]:
                assert (body_center-Vector(other['center'])).length > radius + other['radius'], 'Fruit bodies overlap'
            data[kind].append({'anchor': list(anchor), 'center': list(body_center),
                               'radius': radius, 'angle': angle, 'size': scale})
    assert len(data['leaf']) == result['report']['leaf_count']
    assert len(data['fruit']) == result['report']['fruit_count'] == len(fruit_emitter.data.vertices)
    assert len(data['leaf']) > 0 and len(data['fruit']) > 0
    assert len({tuple(round(v, 6) for v in item['anchor']) for item in data['fruit']}) == len(data['fruit'])
    if len(leaf_roots) > 1:
        assert len(leaf_roots[0] & leaf_roots[1]) < 0.01 * min(len(s) for s in leaf_roots), 'Leaf systems share their seeds/anchors'
    angles = sorted(item['angle'] for item in data['leaf'])
    assert angles[int(len(angles)*0.9)] < 42 and angles[-1] < 55
    assert all(m.pass_index == 1 for m in tree.data.materials)
    for template in result['templates']:
        expected = 2 if template.get('tree_role') == 'leaf_template' else 3
        assert all(m.pass_index == expected for m in template.data.materials)
    digest = hashlib.sha256(json.dumps({'points': [list(p) for p in points], 'data': data}, sort_keys=True).encode()).hexdigest()
    scope['tree_geometry'].frame_camera(bpy.context.scene, scope['camera'], scope['empty'])
    bpy.context.view_layer.update()
    low, high = scope['tree_geometry'].visible_tree_bounds(bpy.context.scene)
    for x in (low.x, high.x):
        for y in (low.y, high.y):
            for z in (low.z, high.z):
                point = world_to_camera_view(bpy.context.scene, scope['camera'], Vector((x, y, z)))
                assert 0 <= point.x <= 1 and 0 <= point.y <= 1 and point.z > 0, 'Camera clips the tree'
    return {'digest': digest, 'leaf_count': len(data['leaf']), 'fruit_count': len(data['fruit']),
            'leaf_angle_median': angles[len(angles)//2], 'leaf_angle_p90': angles[int(len(angles)*0.9)],
            'fruit_angle_max': max(item['angle'] for item in data['fruit']),
            'trunk_diameter_m': measured_diameter, 'height_m': max(p.z for p in points)}


def render_preview(scope, case):
    scene = bpy.context.scene
    scene.render.resolution_x = scene.render.resolution_y = 448
    scene.render.use_compositing = False
    scene.cycles.samples = 12
    scene.cycles.use_denoising = True
    for i, angle in enumerate((0.6, 2.7, 4.8)):
        scope['tree_geometry'].frame_camera(scene, scope['camera'], scope['empty'], azimuth=angle, margin=1.08)
        scene.render.filepath = str(OUTPUT / case / f'preview_{i}.png')
        bpy.ops.render.render(write_still=True)
        header = Path(scene.render.filepath).read_bytes()[:24]
        assert struct.unpack('>II', header[16:24]) == (448, 448)


original_scene = bpy.context.scene
original_objects = set(original_scene.objects)
summaries = {}
first = run_scene('default')
assert bpy.context.scene != original_scene and set(original_scene.objects) == original_objects
summaries['default'] = inspect_tree(first)
print('PASS default_geometry', json.dumps(summaries['default']), flush=True)
render_preview(first, 'default')

# Preflight must preserve the current finished tree on failure.
bad = copy.deepcopy(first['SETTINGS'])
bad['leaves']['assets'][0]['image'] = 'missing.png'
before = set(bpy.context.scene.objects)
try:
    first['tree_geometry'].generate_tree(bad, ROOT)
except FileNotFoundError:
    pass
else:
    raise AssertionError('Missing asset must fail')
assert set(bpy.context.scene.objects) == before
bad = copy.deepcopy(first['SETTINGS'])
bad['leaves']['max_branch_radius_m'] = 1e-8
saved_scene = bpy.context.scene
try:
    first['tree_geometry'].generate_tree(bad, ROOT)
except RuntimeError:
    pass
else:
    raise AssertionError('An unusable branch region must fail')
assert bpy.context.scene == saved_scene and set(saved_scene.objects) == before
print('PASS failure_preserves_finished_tree', flush=True)

repeat = run_scene('repeat')
summaries['repeat'] = inspect_tree(repeat)
assert summaries['repeat']['digest'] == summaries['default']['digest'], 'Same seed/settings must repeat exactly'
print('PASS repeatability', flush=True)

for case, seed, height, fruit, branch_count in [('small', 1, 2.5, 'a', 3), ('large_orange', 7, 4.5, 'o', 5)]:
    changes = (f"SETTINGS['seed']={seed}\nSETTINGS['shape']['height_m']={height}\n"
               f"SETTINGS['shape']['crown_width_m']={height*1.2}\n"
               f"SETTINGS['shape']['main_branch_count']={branch_count}\n")
    scope = run_scene(case, changes, fruit)
    summaries[case] = inspect_tree(scope)
    print('PASS', case, json.dumps(summaries[case]), flush=True)

# A world-space move must keep all attachment points on the moving tree.
tree = scope['result']['trunk']
tree.location = (4, -2, 1)
bpy.context.view_layer.update()
inverse = tree.matrix_world.inverted()
bvh = bvh_for(tree)
for instance in bpy.context.evaluated_depsgraph_get().object_instances:
    if instance.is_instance and instance.particle_system:
        point = inverse @ instance.matrix_world.translation
        assert bvh.find_nearest(point)[3] < 0.0002
tree.location = (0, 0, 0)
print('PASS moved_tree_attachments', flush=True)

# Reweighting an edge by its physical length must not depend on inserted sample nodes.
shape = scope['SETTINGS']['shape']
coarse = [Vector((0, 0, 0)), Vector((0, 0, 1)), Vector((1, 0, 2)), Vector((-1, 0, 2))]
fine = [Vector((0, 0, 0)), Vector((0, 0, .5)), Vector((0, 0, 1)),
        Vector((.5, 0, 1.5)), Vector((1, 0, 2)), Vector((-.5, 0, 1.5)), Vector((-1, 0, 2))]
radii_coarse, _ = scope['tree_geometry'].branch_metrics(coarse, [None, 0, 1, 1], shape)
radii_fine, _ = scope['tree_geometry'].branch_metrics(fine, [None, 0, 1, 2, 3, 2, 5], shape)
for a, b in ((0, 0), (1, 2), (2, 4), (3, 6)):
    assert math.isclose(radii_coarse[a], radii_fine[b], rel_tol=1e-7)
print('PASS length_based_radius_contract', flush=True)

for nodes in ([], [((0, 0, 0), 0)], [((0, 0, 0), None), ((0, 0, 0), 0)],
              [((0, 0, 0), None), ((1, 0, 0), 2)]):
    try:
        plugin.SCA(NENDPOINTS=0, initial_skeleton=nodes)
    except ValueError:
        pass
    else:
        raise AssertionError('Invalid initial skeleton accepted')
print('PASS skeleton_input_validation', flush=True)

# Prove relocation without using the installed plugin or the original script directory.
package = ROOT.parent / 'extension/spacetree-master/release/SCA_Tree_Generator_0.2.17_Blender_5.2.1.zip'
with tempfile.TemporaryDirectory(prefix='tree_portable_') as temp:
    portable = Path(temp) / '小组共享 带空格'
    portable.mkdir()
    with zipfile.ZipFile(package) as archive:
        archive.extractall(portable)
    plugin.unregister()
    for name in list(sys.modules):
        if name == 'add_mesh_space_tree' or name.startswith('add_mesh_space_tree.'):
            del sys.modules[name]
    sys.path.insert(0, str(portable))
    plugin = importlib.import_module('add_mesh_space_tree')
    plugin.register()
    assert Path(plugin.__file__).resolve().is_relative_to(portable.resolve())
    for name in ('space_tree_scene_gen.py', 'tree_geometry.py'):
        shutil.copy2(ROOT / name, portable / name)
    for name in ('leaf_texture', 'fruit_model', 'hdri'):
        shutil.copytree(ROOT / name, portable / name)
    sys.modules.pop('tree_geometry', None)
    moved = run_scene('portable', "SETTINGS['shape']['endpoint_count']=180\nSETTINGS['shape']['max_iterations']=80", root=portable)
    summaries['portable'] = inspect_tree(moved)
    assert Path(moved['tree_geometry'].__file__).resolve().is_relative_to(portable.resolve())
    print('PASS relocated_plugin_and_assets', flush=True)

(OUTPUT / 'geometry_checks.json').write_text(json.dumps(summaries, indent=2), encoding='utf-8')
print('ALL TREE GEOMETRY CHECKS PASSED', OUTPUT, flush=True)
