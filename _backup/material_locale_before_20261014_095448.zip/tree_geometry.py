"""Meter-sized trees, calibrated assets, and branch-attached particle instances."""
import copy
import importlib
import inspect
import json
import math
import random
from pathlib import Path

import bpy
import numpy as np
from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree

OWNER = 'procedural_fruit_tree'


def validate_settings(settings, asset_root):
    settings = copy.deepcopy(settings)
    root = Path(asset_root)
    shape, leaves, fruits = (settings[key] for key in ('shape', 'leaves', 'fruits'))
    for section in (shape, leaves, fruits):
        for key, value in section.items():
            if isinstance(value, (int, float)) and (not math.isfinite(value) or value < 0):
                raise ValueError(f'{key} must be finite and nonnegative')
    for key in ('height_m', 'crown_width_m', 'trunk_diameter_m', 'internode_length_m',
                'kill_distance_m', 'influence_range_m', 'tip_radius_m', 'taper_power'):
        if shape[key] <= 0:
            raise ValueError(f'{key} must be positive')
    for key in ('main_branch_count', 'endpoint_count', 'max_iterations'):
        if type(shape[key]) is not int or shape[key] < 1:
            raise ValueError(f'{key} must be a positive integer')
    if type(settings['seed']) is not int:
        raise ValueError('seed must be an integer')
    if not 0 < shape['bare_trunk_height_m'] < shape['height_m'] * 0.55:
        raise ValueError('bare_trunk_height_m must be between zero and 55% of tree height')
    if shape['tip_radius_m'] >= shape['trunk_diameter_m'] / 2:
        raise ValueError('Tip radius must be smaller than trunk radius')
    if shape['main_branch_count'] * shape['internode_length_m'] > shape['height_m'] * 0.4:
        raise ValueError('Reduce main_branch_count or internode_length_m for this tree height')
    for section, key in ((leaves, 'length_m'), (fruits, 'diameter_m'),
                         (fruits, 'branch_radius_m'), (shape, 'main_branch_elevation_deg')):
        pair = section[key]
        if len(pair) != 2 or not all(math.isfinite(v) for v in pair) or pair[0] > pair[1]:
            raise ValueError(f'{key} must be an ordered, finite pair')
        if key != 'main_branch_elevation_deg' and pair[0] <= 0:
            raise ValueError(f'{key} must be positive')
    if leaves['tilt_random'] > 0.1 or fruits['tilt_random'] > 0.05:
        raise ValueError('Leaf/fruit rotation randomness is outside the calibrated range')
    if not leaves['assets'] or sum(asset['weight'] for asset in leaves['assets']) <= 0:
        raise ValueError('At least one weighted leaf asset is required')
    identifiers = set()
    for asset in leaves['assets']:
        if asset['id'] in identifiers or not math.isfinite(asset['weight']) or asset['weight'] <= 0:
            raise ValueError('Leaf identifiers must be unique and weights positive')
        identifiers.add(asset['id'])
        for key in ('attach_uv', 'tip_uv'):
            if len(asset[key]) != 2 or not all(math.isfinite(v) and 0 <= v <= 1 for v in asset[key]):
                raise ValueError(f'{asset["id"]}: {key} needs a calibrated UV point')
        if asset['attach_uv'] == asset['tip_uv']:
            raise ValueError('Leaf attachment and tip cannot coincide')
        if not (root / asset['image']).is_file():
            raise FileNotFoundError(root / asset['image'])
    asset = fruits['asset']
    if len(asset['attach_point']) != 3 or not all(math.isfinite(v) for v in asset['attach_point']):
        raise ValueError('Fruit attach_point must be calibrated in imported mesh coordinates')
    if not asset['body_materials'] or not all(type(i) is int and i >= 0 for i in asset['body_materials']):
        raise ValueError('Fruit body_materials must identify the fruit body material slots')
    for key in ('obj', 'base_color', 'normal_map'):
        if asset.get(key) and not (root / asset[key]).is_file():
            raise FileNotFoundError(root / asset[key])
    if asset.get('normal_map') == asset['base_color']:
        raise ValueError('A color texture cannot also be used as a tangent-space normal map')
    try:
        bpy.ops.mesh.sca_tree.get_rna_type()
    except KeyError:
        raise RuntimeError('Enable SCA Tree Generator before running this script.') from None
    plugin = importlib.import_module('add_mesh_space_tree')
    if 'initial_skeleton' not in inspect.signature(plugin.SCA).parameters:
        raise RuntimeError('Install SCA Tree Generator 0.2.17 or newer, then restart Blender.')
    return settings


def _scaffold(shape, seed):
    rng = random.Random(seed + 31)
    height, bare, step = (shape[k] for k in ('height_m', 'bare_trunk_height_m', 'internode_length_m'))
    leader = max(height * 0.60, bare + (shape['main_branch_count'] + 1) * step)
    count = math.ceil(leader / step)
    nodes = [(Vector((0, 0, 0)), None)]
    for i in range(1, count + 1):
        z = leader * i / count
        bend = max(0, z - bare) * 0.025
        nodes.append((Vector((bend * math.sin(z), bend * math.cos(z), z)), i - 1))
    trunk_nodes = set(range(len(nodes)))
    targets = np.linspace(bare + step, leader - step, shape['main_branch_count'])
    attachments = [min(range(1, count), key=lambda i: abs(nodes[i][0].z - z)) for z in targets]
    if len(set(attachments)) != len(attachments):
        raise ValueError('The main branches need distinct trunk nodes; reduce their count')
    for k, parent in enumerate(attachments):
        origin = nodes[parent][0]
        azimuth = 2 * math.pi * k / len(attachments) + rng.uniform(-0.13, 0.13)
        elevation = math.radians(rng.uniform(*shape['main_branch_elevation_deg']))
        reach = shape['crown_width_m'] * rng.uniform(0.32, 0.38)
        length = reach / math.cos(elevation)
        parts = math.ceil(length / step)
        for j in range(1, parts + 1):
            fraction = j / parts
            turn = azimuth + 0.08 * math.sin(fraction * math.pi)
            point = origin + Vector((reach * fraction * math.cos(turn),
                                     reach * fraction * math.sin(turn),
                                     reach * fraction * math.tan(elevation)))
            nodes.append((point, parent))
            parent = len(nodes) - 1
    return nodes, trunk_nodes


def _grow(shape, seed):
    plugin = importlib.import_module('add_mesh_space_tree')
    scaffold, trunk_nodes = _scaffold(shape, seed)
    radius = shape['crown_width_m'] / 2
    half_height = (shape['height_m'] - shape['bare_trunk_height_m']) / 2
    center_z = shape['bare_trunk_height_m'] + half_height
    rng = random.Random(seed + 11)

    def volume():
        while True:
            x, y, z = (rng.uniform(-1, 1) for _ in range(3))
            if x*x + y*y + z*z <= 1:
                yield Vector((x * radius, y * radius, center_z + z * half_height))

    def exclude(point):
        return (point.z < shape['bare_trunk_height_m'] or
                (point.x / radius)**2 + (point.y / radius)**2 +
                ((point.z - center_z) / half_height)**2 > 1)

    growth = plugin.SCA(NENDPOINTS=shape['endpoint_count'], NBP=shape['max_iterations'],
                        d=shape['internode_length_m'], KILLDIST=shape['kill_distance_m'],
                        INFLUENCE=shape['influence_range_m'], SEED=seed,
                        volume=volume, exclude=exclude, initial_skeleton=scaffold,
                        apicalcontrol=0.3, apicalcontrolfalloff=1.5, apicaltiming=8)
    growth.iterate()
    points = [bp.v.copy() for bp in growth.branchpoints]
    parents = [bp.parent for bp in growth.branchpoints]
    radii, tip_distance = branch_metrics(points, parents, shape)
    return growth, points, parents, radii, tip_distance, trunk_nodes


def branch_metrics(points, parents, shape):
    children = [[] for _ in points]
    for i, parent in enumerate(parents):
        if parent is not None:
            children[parent].append(i)
    downstream, tip_distance = [0.0] * len(points), [0.0] * len(points)
    for i in reversed(range(len(points))):
        distances = [(points[j] - points[i]).length for j in children[i]]
        downstream[i] = sum(d + downstream[j] for d, j in zip(distances, children[i]))
        tip_distance[i] = min((d + tip_distance[j] for d, j in zip(distances, children[i])), default=0)
    if downstream[0] <= 0:
        raise ValueError('Tree growth produced no branches')
    radii = [max(shape['tip_radius_m'], shape['trunk_diameter_m'] / 2 *
                 (value / downstream[0]) ** shape['taper_power']) for value in downstream]
    return radii, tip_distance


def _calibrate_trunk(tree, points, radii, shape):
    skin_data = tree.data.skin_vertices[0].data
    for vertex, radius in zip(skin_data, radii):
        vertex.radius = (radius, radius)
    bpy.context.view_layer.update()
    evaluated = tree.evaluated_get(bpy.context.evaluated_depsgraph_get())
    z = shape['bare_trunk_height_m'] * 0.5
    i = next(i for i in range(1, len(points)) if points[i].z >= z)
    fraction = (z - points[i-1].z) / (points[i].z - points[i-1].z)
    center = points[i-1].lerp(points[i], fraction)
    distances = []
    for direction in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0)):
        hit, location, normal, index = evaluated.ray_cast(center, Vector(direction),
                                                         distance=shape['trunk_diameter_m'] * 5)
        if not hit:
            raise RuntimeError('Skin did not create a continuous trunk cross-section')
        distances.append((location - center).length)
    measured = sum(distances) / 2
    correction = shape['trunk_diameter_m'] / measured
    for vertex, radius in zip(skin_data, radii):
        vertex.radius = (radius * correction, radius * correction)
    bpy.context.view_layer.update()
    return measured, correction


def _material(name, color, class_id):
    material = bpy.data.materials.new(name)
    material[OWNER] = True
    material.diffuse_color = (*color, 1)
    material.pass_index = class_id
    material.use_nodes = True
    shader = material.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value = (*color, 1)
    shader.inputs['Roughness'].default_value = 0.55
    return material, shader


def _image(path, color_space='sRGB'):
    image = bpy.data.images.load(str(path), check_existing=True)
    image.colorspace_settings.name = color_space
    return image


def _bark(tree):
    material, shader = _material('Tree Bark', (0.14, 0.055, 0.018), 1)
    nodes, links = material.node_tree.nodes, material.node_tree.links
    coordinates = nodes.new('ShaderNodeTexCoord')
    noise = nodes.new('ShaderNodeTexNoise')
    noise.inputs['Scale'].default_value = 45
    noise.inputs['Detail'].default_value = 2
    links.new(coordinates.outputs['Object'], noise.inputs['Vector'])
    ramp = nodes.new('ShaderNodeValToRGB')
    ramp.color_ramp.elements[0].color = (0.07, 0.026, 0.008, 1)
    ramp.color_ramp.elements[1].color = (0.25, 0.12, 0.04, 1)
    links.new(noise.outputs['Fac'], ramp.inputs['Fac'])
    links.new(ramp.outputs['Color'], shader.inputs['Base Color'])
    bump = nodes.new('ShaderNodeBump')
    bump.inputs['Strength'].default_value = 0.18
    bump.inputs['Distance'].default_value = 0.0015
    links.new(noise.outputs['Fac'], bump.inputs['Height'])
    links.new(bump.outputs['Normal'], shader.inputs['Normal'])
    tree.data.materials.clear()
    tree.data.materials.append(material)


def _leaf_template(asset, root, collection):
    image = _image(root / asset['image'])
    width, height = image.size
    pixels = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(pixels)
    rows, columns = np.where(pixels.reshape(height, width, 4)[:, :, 3] > 0.25)
    if not len(rows) or np.ptp(columns) == 0:
        raise ValueError(f'{asset["id"]}: no usable leaf alpha mask')
    bounds = (columns.min() / width, rows.min() / height,
              (columns.max()+1) / width, (rows.max()+1) / height)
    attach = Vector((asset['attach_uv'][0] * width, asset['attach_uv'][1] * height))
    tip = Vector((asset['tip_uv'][0] * width, asset['tip_uv'][1] * height))
    length = (tip - attach).length
    forward = (tip - attach).normalized()
    side = Vector((-forward.y, forward.x))
    vertices, uvs, faces = [], [], []
    for j in range(5):
        for i in range(3):
            u = bounds[0] + (bounds[2] - bounds[0]) * i / 2
            v = bounds[1] + (bounds[3] - bounds[1]) * j / 4
            q = Vector((u * width, v * height)) - attach
            x, y = q.dot(forward) / length, q.dot(side) / length
            vertices.append((x, y, 0.018 * max(0, x)**2))
            uvs.append((u, v))
    for j in range(4):
        for i in range(2):
            a = j * 3 + i
            faces.append((a, a+1, a+4, a+3))
    mesh = bpy.data.meshes.new(asset['id'])
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    layer = mesh.uv_layers.new(name='Leaf UV')
    for loop in mesh.loops:
        layer.data[loop.index].uv = uvs[loop.vertex_index]
    obj = bpy.data.objects.new(asset['id'], mesh)
    collection.objects.link(obj)
    obj.hide_render = True
    obj.hide_set(True)
    obj['tree_role'] = 'leaf_template'
    obj['leaf_axis'] = (1.0, 0.0, 0.0)
    obj['leaf_normal'] = (0.0, 0.0, 1.0)
    obj['unit_leaf_area'] = len(rows) / (length * length)
    material, shader = _material(asset['id'] + ' Material', (0.12, 0.32, 0.025), 2)
    texture = material.node_tree.nodes.new('ShaderNodeTexImage')
    texture.image = image
    links = material.node_tree.links
    links.new(texture.outputs['Color'], shader.inputs['Base Color'])
    links.new(texture.outputs['Alpha'], shader.inputs['Alpha'])
    shader.inputs['Roughness'].default_value = 0.6
    shader.inputs['Subsurface Weight'].default_value = 0.04
    mesh.materials.append(material)
    return obj


def _fruit_template(asset, root, collection):
    before = set(bpy.data.objects)
    bpy.ops.wm.obj_import(filepath=str(root / asset['obj']))
    imported = list(set(bpy.data.objects) - before)
    objects = [obj for obj in imported if obj.type == 'MESH']
    if not objects:
        raise ValueError('Fruit OBJ contains no mesh')
    for obj in objects:
        for old_collection in list(obj.users_collection):
            old_collection.objects.unlink(obj)
        collection.objects.link(obj)
    for obj in bpy.context.selected_objects:
        obj.select_set(False)
    for obj in objects:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = objects[0]
    if len(objects) > 1:
        bpy.ops.object.join()
    obj = bpy.context.view_layer.objects.active
    obj.name = asset['id']
    mesh = obj.data
    body_slots = set(asset['body_materials'])
    body_ids = sorted({i for poly in mesh.polygons if poly.material_index in body_slots for i in poly.vertices})
    if not body_ids or not body_slots <= {poly.material_index for poly in mesh.polygons}:
        raise ValueError('Fruit body material slots do not match this OBJ')
    center = sum((mesh.vertices[i].co for i in body_ids), Vector()) / len(body_ids)
    attachment = Vector(asset['attach_point'])
    if (attachment - center).length <= 1e-6:
        raise ValueError('The fruit stem attachment must be outside the body center')
    rotation = (attachment - center).normalized().rotation_difference(Vector((1, 0, 0)))
    body = [rotation @ (mesh.vertices[i].co - attachment) for i in body_ids]
    diameter = max(max(v[j] for v in body) - min(v[j] for v in body) for j in (1, 2))
    if diameter <= 1e-6:
        raise ValueError('Fruit body has zero diameter')
    connector = 0.12
    for vertex in mesh.vertices:
        vertex.co = rotation @ (vertex.co - attachment) / diameter - Vector((connector, 0, 0))
    obj.matrix_world = Matrix.Identity(4)
    body_center = sum((mesh.vertices[i].co for i in body_ids), Vector()) / len(body_ids)
    body_radius = max((mesh.vertices[i].co - body_center).length for i in body_ids)
    body_material, shader = _material(asset['id'] + ' Skin', (0.55, 0.08, 0.03), 3)
    texture = body_material.node_tree.nodes.new('ShaderNodeTexImage')
    texture.image = _image(root / asset['base_color'])
    body_material.node_tree.links.new(texture.outputs['Color'], shader.inputs['Base Color'])
    shader.inputs['Roughness'].default_value = 0.38
    if asset.get('normal_map'):
        nodes, links = body_material.node_tree.nodes, body_material.node_tree.links
        texture = nodes.new('ShaderNodeTexImage')
        texture.image = _image(root / asset['normal_map'], 'Non-Color')
        normal = nodes.new('ShaderNodeNormalMap')
        normal.inputs['Strength'].default_value = 0.2
        links.new(texture.outputs['Color'], normal.inputs['Color'])
        links.new(normal.outputs['Normal'], shader.inputs['Normal'])
    stem_material, stem_shader = _material(asset['id'] + ' Stem', (0.13, 0.055, 0.012), 3)
    material_indices = [0 if poly.material_index in body_slots else 1 for poly in mesh.polygons]
    mesh.materials.clear()
    mesh.materials.append(body_material)
    mesh.materials.append(stem_material)
    for poly, index in zip(mesh.polygons, material_indices):
        poly.material_index = index
        poly.use_smooth = True
    # A short stem joins the surface anchor to the asset's calibrated stem tip.
    import bmesh
    bm = bmesh.new()
    bm.from_mesh(mesh)
    result = bmesh.ops.create_cone(bm, cap_ends=True, segments=8, radius1=0.014,
                                 radius2=0.010, depth=connector,
                                 matrix=Matrix.Translation((-connector/2, 0, 0)) @
                                 Matrix.Rotation(math.pi/2, 4, 'Y'))
    created = set(result['verts'])
    for face in bm.faces:
        if all(v in created for v in face.verts):
            face.material_index = 1
    bm.to_mesh(mesh)
    bm.free()
    smooth = obj.modifiers.new('Fruit Smooth', 'SUBSURF')
    smooth.levels = smooth.render_levels = 1
    obj['body_center'] = list(body_center)
    obj['body_radius'] = body_radius
    obj['tree_role'] = 'fruit_template'
    obj.hide_render = True
    obj.hide_set(True)
    return obj


def _surface(tree, group_name, min_height, kind):
    group_index = tree.vertex_groups[group_name].index
    density_index = tree.vertex_groups[group_name + ' Density'].index
    dg = bpy.context.evaluated_depsgraph_get()
    obj = tree.evaluated_get(dg)
    mesh = obj.to_mesh(preserve_all_data_layers=True, depsgraph=dg)
    records = []
    try:
        mesh.calc_loop_triangles()
        for triangle in mesh.loop_triangles:
            vertices = [mesh.vertices[i] for i in triangle.vertices]
            if any(v.co.z < min_height or
                   next((g.weight for g in v.groups if g.group == group_index), 0) < 0.999
                   for v in vertices):
                continue
            normal = triangle.normal.copy()
            if (kind == 'leaf' and abs(normal.z) > 0.4) or (kind == 'fruit' and normal.z > -0.2):
                continue
            density = sum(next((g.weight for g in v.groups if g.group == density_index), 0)
                          for v in vertices) / 3
            positions = [v.co.copy() for v in vertices]
            area = (positions[1]-positions[0]).cross(positions[2]-positions[0]).length / 2
            if area > 1e-12 and density > 0:
                records.append((positions, normal, area, density))
    finally:
        obj.to_mesh_clear()
    return records


def _leaf_emitter(tree, records, collection):
    if not records:
        raise RuntimeError('No leaf-bearing twigs: check branch radius and terminal distance settings')
    vertices, faces, weights, samples, lookup = [], [], [], [], {}
    for positions, normal, area, density in records:
        face = []
        for point in positions:
            key = tuple(point)
            if key not in lookup:
                lookup[key] = len(vertices)
                vertices.append(point)
                weights.append(0.0)
                samples.append(0)
            index = lookup[key]
            weights[index] += density
            samples[index] += 1
            face.append(index)
        faces.append(tuple(face))
    mesh = bpy.data.meshes.new('LeafEmitter')
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    uv = mesh.uv_layers.new(name='Branch Direction')
    for poly in mesh.polygons:
        v_direction = Vector((0, 0, 1)).cross(poly.normal).normalized()
        u_direction = v_direction.cross(poly.normal)
        for i in poly.loop_indices:
            point = mesh.vertices[mesh.loops[i].vertex_index].co
            uv.data[i].uv = (point.dot(u_direction), point.dot(v_direction))
    emitter = _emitter_object('LeafEmitter', mesh, tree, collection, 'leaf_emitter')
    group = emitter.vertex_groups.new(name='Density')
    for i, weight in enumerate(weights):
        group.add([i], weight / samples[i], 'REPLACE')
    return emitter


def _emitter_object(name, mesh, tree, collection, role):
    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    obj.parent = tree
    obj.matrix_parent_inverse = obj.matrix_basis = Matrix.Identity(4)
    obj.show_instancer_for_viewport = obj.show_instancer_for_render = False
    obj['tree_role'] = role
    return obj


def _fruit_emitter(tree, records, template, settings, count, seed, collection):
    if count and not records:
        raise RuntimeError('No downward fruit-bearing branch surfaces')
    rng = random.Random(seed + 301)
    dg = bpy.context.evaluated_depsgraph_get()
    obj = tree.evaluated_get(dg)
    mesh = obj.to_mesh()
    try:
        mesh.calc_loop_triangles()
        bvh = BVHTree.FromPolygons([v.co for v in mesh.vertices],
                                  [tuple(t.vertices) for t in mesh.loop_triangles], all_triangles=True)
    finally:
        obj.to_mesh_clear()
    weights = [area * density for positions, normal, area, density in records]
    anchors, centers = [], []
    diameter = settings['diameter_m'][1]
    body_offset = Vector(template['body_center']) * diameter
    body_radius = template['body_radius'] * diameter
    # Cover the small change in fruit center caused by its permitted inclination.
    envelope = body_radius + body_offset.length * math.sin(math.pi * settings['tilt_random'])
    for attempt in range(max(1, count * 120)):
        if len(anchors) == count:
            break
        positions, normal, area, density = rng.choices(records, weights=weights)[0]
        a, b = rng.random(), rng.random()
        if a + b > 1:
            a, b = 1-a, 1-b
        anchor = positions[0] + a * (positions[1]-positions[0]) + b * (positions[2]-positions[0])
        center = anchor + Vector((0, 0, body_offset.x))
        closest, normal, index, distance = bvh.find_nearest(center)
        if distance < envelope + 0.001 or center.z - envelope < 0:
            continue
        if any((center - other).length < 2 * envelope + 0.004 for other in centers):
            continue
        anchors.append(anchor)
        centers.append(center)
    if count and not anchors:
        raise RuntimeError('Fruit bodies cannot clear these branches; reduce fruit size or change the tree shape')
    mesh = bpy.data.meshes.new('FruitEmitter')
    mesh.from_pydata(anchors, [], [])
    mesh.update()
    emitter = _emitter_object('FruitEmitter', mesh, tree, collection, 'fruit_emitter')
    emitter['requested_count'] = count
    emitter['accepted_count'] = len(anchors)
    emitter['body_envelope_m'] = envelope
    return emitter, len(anchors)


def _particles(emitter, prototype, count, size_range, seed, tilt_random, kind):
    system = emitter.modifiers.new(prototype.name, 'PARTICLE_SYSTEM').particle_system
    system.seed = seed
    p = system.settings
    p.type = 'HAIR'
    p.use_advanced_hair = True
    p.hair_step = 1
    p.hair_length = 1
    p.count = count
    p.emit_from = 'FACE' if kind == 'leaf' else 'VERT'
    p.use_emit_random = kind == 'leaf'
    p.use_even_distribution = True
    p.distribution = 'RAND'
    p.use_modifier_stack = True
    p.render_type = 'OBJECT'
    p.instance_object = prototype
    p.use_scale_instance = False
    p.use_rotation_instance = True
    p.use_rotations = True
    p.particle_size = size_range[1]
    p.size_random = 1 - size_range[0] / size_range[1]
    p.rotation_factor_random = tilt_random
    if kind == 'leaf':
        system.vertex_group_density = 'Density'
        p.rotation_mode = 'NOR_TAN'
        p.phase_factor = -0.08
        p.phase_factor_random = 0.16
    else:
        p.rotation_mode = 'GLOB_Z'
        p.phase_factor_random = 2
    return system


def _remove_collection(collection):
    for child in list(collection.children):
        _remove_collection(child)
    for obj in list(collection.objects):
        data = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if isinstance(data, bpy.types.Mesh) and data.users == 0:
            bpy.data.meshes.remove(data)
    bpy.data.collections.remove(collection)


def select_tree_layer(scene, collection):
    layer = scene.view_layers.get('FruitTree')
    if layer is None:
        layer = scene.view_layers[0]
        layer.name = 'FruitTree'
    bpy.context.view_layer.update()
    for child in layer.layer_collection.children:
        child.exclude = child.collection != collection
    if bpy.context.window:
        bpy.context.window.view_layer = layer
    scene.render.use_single_layer = True
    scene['tree_collection'] = collection.name
    return layer


def generate_tree(settings, asset_root):
    settings = validate_settings(settings, asset_root)
    root, source_scene = Path(asset_root), bpy.context.scene
    created_scene = not (source_scene.get(OWNER) and source_scene.get('tree_collection'))
    scene = bpy.data.scenes.new('FruitTree') if created_scene else source_scene
    if created_scene:
        scene[OWNER] = True
        bpy.context.window.scene = scene
    shape, leaves, fruits = (settings[key] for key in ('shape', 'leaves', 'fruits'))
    stage = bpy.data.collections.new('GeneratedTree Building')
    scene.collection.children.link(stage)
    stage[OWNER] = True
    old_cursor = scene.cursor.location.copy()
    scene_alive = True
    try:
        growth, points, parents, radii, tip_distance, trunk_nodes = _grow(shape, settings['seed'])
        scene.cursor.location = (0, 0, 0)
        plugin = importlib.import_module('add_mesh_space_tree')
        with bpy.context.temp_override(collection=stage):
            tree = plugin.createGeometry(growth, power=shape['taper_power'], scale=0.01,
                                         nomodifiers=False, skinmethod='BLENDER', subsurface=False)
        tree['tree_role'] = 'trunk'
        for modifier in tree.modifiers:
            if modifier.type == 'SUBSURF':
                modifier.levels = modifier.render_levels = 1
        measured, correction = _calibrate_trunk(tree, points, radii, shape)
        _bark(tree)
        groups = {name: tree.vertex_groups.new(name=name)
                  for name in ('LeafRegion', 'FruitRegion', 'LeafRegion Density', 'FruitRegion Density')}
        leaf_flags, fruit_flags = [], []
        for i, (point, radius) in enumerate(zip(points, radii)):
            common = i not in trunk_nodes and point.z >= shape['bare_trunk_height_m']
            leaf = common and radius <= leaves['max_branch_radius_m'] and tip_distance[i] <= leaves['distance_to_tip_m']
            fruit = common and fruits['branch_radius_m'][0] <= radius <= fruits['branch_radius_m'][1]
            leaf_flags.append(leaf)
            fruit_flags.append(fruit)
            for name, valid in (('LeafRegion', leaf), ('FruitRegion', fruit)):
                groups[name].add([i], float(valid), 'REPLACE')
                groups[name + ' Density'].add([i], shape['tip_radius_m']/radius if valid else 0, 'REPLACE')
        leaf_length = sum((points[i]-points[parent]).length for i, parent in enumerate(parents)
                          if parent is not None and leaf_flags[i] and leaf_flags[parent])
        fruit_length = sum((points[i]-points[parent]).length for i, parent in enumerate(parents)
                           if parent is not None and fruit_flags[i] and fruit_flags[parent])
        bpy.context.view_layer.update()
        prototypes = bpy.data.collections.new('Tree Prototypes')
        stage.children.link(prototypes)
        templates = [_leaf_template(asset, root, prototypes) for asset in leaves['assets']]
        fruit_template = _fruit_template(fruits['asset'], root, prototypes)
        leaf_surface = _surface(tree, 'LeafRegion', shape['bare_trunk_height_m'], 'leaf')
        fruit_surface = _surface(tree, 'FruitRegion', shape['bare_trunk_height_m'], 'fruit')
        leaf_emitter = _leaf_emitter(tree, leaf_surface, stage)
        total_leaves = round(leaves['per_meter'] * leaf_length)
        if leaves['per_meter'] > 0 and total_leaves == 0:
            raise RuntimeError('The tree has no useful leaf-bearing branch length')
        weights = [asset['weight'] for asset in leaves['assets']]
        exact_counts = [total_leaves * weight / sum(weights) for weight in weights]
        counts = [math.floor(value) for value in exact_counts]
        for i in sorted(range(len(counts)), key=lambda i: exact_counts[i]-counts[i], reverse=True)[:total_leaves-sum(counts)]:
            counts[i] += 1
        for i, (template, count) in enumerate(zip(templates, counts)):
            _particles(leaf_emitter, template, count, leaves['length_m'], settings['seed']+101+i*17,
                       leaves['tilt_random'], 'leaf')
        fruit_emitter, count = _fruit_emitter(tree, fruit_surface, fruit_template, fruits,
                                              round(fruits['per_meter'] * fruit_length), settings['seed'], stage)
        if count:
            _particles(fruit_emitter, fruit_template, count, fruits['diameter_m'], settings['seed']+501,
                       fruits['tilt_random'], 'fruit')
        scene.frame_set(1)
        bpy.context.view_layer.update()
        for previous in list(scene.collection.children):
            if previous != stage and previous.get(OWNER):
                _remove_collection(previous)
        stage.name = 'GeneratedTree'
        tree.name = 'Tree'
        leaf_emitter.name = 'LeafEmitter'
        fruit_emitter.name = 'FruitEmitter'
        ground_mesh = bpy.data.meshes.new('Tree Ground')
        extent = shape['crown_width_m'] * 4
        ground_mesh.from_pydata([(-extent, -extent, 0), (extent, -extent, 0),
                                 (extent, extent, 0), (-extent, extent, 0)], [], [(0, 1, 2, 3)])
        ground = bpy.data.objects.new('Tree Ground', ground_mesh)
        stage.objects.link(ground)
        ground['tree_role'] = 'ground'
        ground.is_shadow_catcher = True
        ground_material, ground_shader = _material('Tree Ground', (0.3, 0.3, 0.3), 0)
        ground_mesh.materials.append(ground_material)
        select_tree_layer(scene, stage)
        scene.unit_settings.system = 'METRIC'
        scene.unit_settings.scale_length = 1
        report = {'nodes': len(points), 'main_branches': shape['main_branch_count'],
                  'leaf_branch_length_m': leaf_length, 'fruit_branch_length_m': fruit_length,
                  'leaf_count': total_leaves, 'fruit_requested': fruit_emitter['requested_count'],
                  'fruit_count': count, 'trunk_radius_correction': correction,
                  'leaf_surface_triangles': len(leaf_surface), 'fruit_surface_triangles': len(fruit_surface)}
        a, b = leaves['length_m']
        report['leaf_area_m2'] = sum(t['unit_leaf_area'] * n * (a*a+a*b+b*b)/3
                                     for t, n in zip(templates, counts))
        report['leaf_area_per_crown_area'] = report['leaf_area_m2'] / (math.pi*(shape['crown_width_m']/2)**2)
        tree['generation_report'] = json.dumps(report)
        scene['tree_settings'] = json.dumps(settings)
        print('TREE_GENERATION', json.dumps(report), flush=True)
        return {'trunk': tree, 'leaf_emitter': leaf_emitter, 'fruit_emitter': fruit_emitter,
                'templates': templates + [fruit_template], 'collection': stage, 'report': report,
                'points': points, 'parents': parents, 'radii': radii, 'trunk_nodes': trunk_nodes}
    except Exception:
        _remove_collection(stage)
        if created_scene:
            bpy.context.window.scene = source_scene
            bpy.data.scenes.remove(scene)
            scene_alive = False
        raise
    finally:
        if scene_alive:
            scene.cursor.location = old_cursor


def visible_tree_bounds(scene, depsgraph=None):
    depsgraph = depsgraph or bpy.context.evaluated_depsgraph_get()
    collection = bpy.data.collections.get(scene.get('tree_collection', ''))
    members = set(collection.all_objects) if collection else set(scene.objects)
    low, high = Vector((math.inf,)*3), Vector((-math.inf,)*3)
    found = False
    for instance in depsgraph.object_instances:
        obj = instance.object
        if obj.type not in {'MESH', 'CURVE'} or obj.original.get('tree_role') == 'ground':
            continue
        owner = instance.parent.original if instance.is_instance and instance.parent else obj.original
        if owner not in members:
            continue
        if not instance.is_instance and (obj.original.hide_render or
                                        not obj.original.show_instancer_for_render):
            continue
        matrix = instance.matrix_world.copy()
        for corner in obj.bound_box:
            point = matrix @ Vector(corner)
            for i in range(3):
                low[i], high[i] = min(low[i], point[i]), max(high[i], point[i])
            found = True
    if not found:
        raise RuntimeError('No visible tree geometry was found')
    return low, high


def frame_camera(scene, camera, target, azimuth=0.6, elevation=0.16, margin=1.18):
    bpy.context.view_layer.update()
    low, high = visible_tree_bounds(scene)
    center = (low + high) / 2
    radius = (high - low).length / 2
    direction = Vector((math.cos(azimuth)*math.cos(elevation),
                        math.sin(azimuth)*math.cos(elevation), math.sin(elevation)))
    # view_frame includes sensor fit and image aspect; angle_y alone does not.
    frame = camera.data.view_frame(scene=scene)
    tan_x = max(abs(corner.x / corner.z) for corner in frame)
    tan_y = max(abs(corner.y / corner.z) for corner in frame)
    inverse = (-direction).to_track_quat('-Z', 'Y').inverted()
    corners = [inverse @ (Vector((x, y, z))-center)
               for x in (low.x, high.x) for y in (low.y, high.y) for z in (low.z, high.z)]
    distance = max(corner.z + margin * max(abs(corner.x) / tan_x, abs(corner.y) / tan_y)
                   for corner in corners)
    target.location = center
    camera.location = center + direction * distance
    camera.data.clip_start = max(0.001, radius * 0.001)
    camera.data.clip_end = distance + radius * 5
    return low, high
