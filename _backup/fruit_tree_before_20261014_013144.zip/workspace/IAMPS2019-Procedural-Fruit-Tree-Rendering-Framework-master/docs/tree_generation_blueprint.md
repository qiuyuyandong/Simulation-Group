# 果树生成脚本实施蓝图

版本：2026-10-14；状态：设计待确认，正式生成脚本和已安装插件尚未按此方案修改。

目标：主干清楚、树冠较低且开展的果园苹果树。复用范围是不同树高、冠幅、随机种子、叶片贴图和 OBJ 果实；苹果树只是第一份参数配置，不把苹果的尺寸、文件名或某棵树的顶点编号写进算法。

**1. 对“分开 Tree”的判断**

当前叶片和果实确实都是 HAIR 粒子的 OBJECT 实例，发射器都是整个 Tree。分离主干与枝条能改善发射区域，但“枝条”里仍包含粗主枝和细末梢；对象名称本身也不表达叶柄位置、叶片方向和果柄方向。

建议保留连续的树木渲染网格，并从其中自动提取两套合法发射表面：

```text
GeneratedTree
├─ Tree                 完整、可见的主干与枝条
├─ LeafEmitter          只含允许长叶的细枝表面，承载叶片粒子
├─ FruitEmitter         只含允许挂果的枝条表面，承载果实粒子
└─ Prototypes           校准后的叶片和水果模板，不直接渲染
```

LeafEmitter、FruitEmitter 可以单独命名、选择、调粒子参数。发射表面从 Tree 的最终评估网格提取，所以能贴合实际可见枝条。把渲染用主干与枝条直接切成两件，容易在分叉处产生接缝，也会增加合并、平滑和重新生成时的维护工作。

顶点组是区域计算的中间数据：LeafRegion、FruitRegion 使用明确的半径、末端距离、主干归属和高度条件，不直接复用插件现有的 Leaves 权重。原 Leaves 组按连接数量分配权重，大部分顶点都有正权重，不能可靠排除粗枝和低处枝条。

**2. 已验证的现状与角度问题**

- 当前磁盘脚本生成约 10.3 单位高的树。四套叶片共 5750 片，两套各 2000 片的绿叶挂接坐标完全重合。
- 当前 HAIR + OBJECT 设置中，hair_length 从 4 改到 1，会使实例缩小到四分之一，实例原点仍在毛发根部。不要用粒子的 hair tip/location 判断物体的实际挂接位置。
- 一套 2000 片绿叶中，1651 片与地面的夹角大于 60°，中位倾角约 78.1°。
- 只设置 use_rotations=True、rotation_mode='GLOB_Z'，这套叶片全部竖直；还必须校准模板轴并启用实例物体旋转。
- 对当前 XY 平面模板，绕本地 Y 轴旋转 90°，并开启 use_rotation_instance 后，再设置 rotation_factor_random=0.2，测试得到中位倾角约 20.4°、90 分位约 32.0°、最大约 35.9°。这是当前模板和种子的测试结果，不是所有模型的保证值。
- 叶片图片有很大的透明留白，图片边界不等于实际叶身边界。应按叶柄基点到叶尖的有效长度标定尺寸。

“较多叶片以低倾角展开”适合作为这份苹果树配置的视觉目标；不会把所有树种、所有叶片都固定成完全水平。苹果冠层研究也分别处理叶片倾角、扭转角和枝条挂接，而不是仅设置一个统一角度。[苹果冠层重建研究](https://www.frontiersin.org/journals/plant-science/articles/10.3389/fpls.2023.1117051/full)。

**3. 文件与修改落点**

以下行号对应本轮检查的文件，实施后会变化。新增模块、配置和测试是计划中的文件，当前只新增本蓝图。

框架目录是 `D:/Cowork/Simulation_Group/IAMPS2019-Procedural-Fruit-Tree-Rendering-Framework-master/`；表中框架脚本、新模块、配置、测试都位于此目录。`extension/...` 的起点是 `D:/Cowork/Simulation_Group/`。已安装插件位于 `C:/Users/迷失/AppData/Roaming/Blender Foundation/Blender/5.2/scripts/addons/add_mesh_space_tree/`，与工作区源码分开管理。

| 文件 | 修改落点与方法 | 功效 |
|---|---|---|
| `space_tree_scene_gen.py` | 53、80 行附近的两次造树替换为一次共享生成调用；113–377 行的按文件名缩放、六段粒子和软体设置替换为模板校准、发射器提取、参数循环 | 消除重复造树和重复参数块，重跑不同配置使用同一流程 |
| `tree_geometry.py`，新增 | 集中实现配置校验、骨架读取、粗细标定、区域划分、模板校准、发射器和粒子创建、包围盒计算 | 可复用算法只在一个文件修改 |
| `tree_settings.json`，新增 | 存放物理尺寸、生长参数、叶片与果实密度、资产校准信息、随机种子 | 换树、换素材修改数据，不修改算法 |
| `extension/spacetree-master/src/add_mesh_space_tree/scanew.py` | SCA 构造函数约 69 行新增可选 initial_skeleton；初始化完整父子骨架，再采样吸引点 | 可用参数构建主干和主枝框架，再让 SCA 生长侧枝，避免只靠随机吸引点猜果园树形 |
| `extension/spacetree-master/src/add_mesh_space_tree/__init__.py` | 复用 285 行 createGeometry 的 BLENDER Skin；核对 359–385 行修改器顺序；修正 444–468 行距离、半径说明 | 连续枝干有体积，参数单位与实际算法一致 |
| `space_tree_scene_gen.py` | 382–610 行简化叶、果材质；624 行附近按实际模板材料设置类别；811 行附近初始化相机 | 改善灰白、金属感和苹果错误法线，保留分类输出 |
| `rendering_loop.py` | 71–86、115–128 行固定相机范围替换为包围盒与视角计算；设置独立的相机随机源 | 树高与冠幅改变后仍能正确取景，不受造树内部随机调用影响 |
| `tests/blender_compat_smoke.py` | 删除“必须六个粒子系统/固定100果实”的断言；改为检查角色、尺寸、实例和标签；同步新的场景保留规则 | 检查最终行为，避免把旧实现写死成标准 |
| `tests/blender_tree_geometry_check.py`，新增 | 检查不同尺寸、种子、模板、发射区域、角度和可重复性 | 验证复用能力，防止只把一棵树调好 |
| 框架 README、插件 README/使用说明、发行 ZIP | 记录配置字段、模板标定、发射器使用方式；若插件接口修改则更新源代码、测试和新版本 ZIP | 分享的代码与本机运行版本一致 |

不在本轮直接重做 `sapling_tree_scene_gen.py` 的生长逻辑。新的包围盒函数须兼容它的曲线树与粒子实例，现有兼容检查继续跑。Sapling 若要使用这套区域划分，需要把曲线枝条转换成同样的骨架接口，不能假装它已经兼容 SCA 的节点结构。

**4. 配置与模块接口**

统一一 Blender 单位为一米。将物理尺寸烘焙到骨架/模板网格，生成后的对象 scale 保持 1，避免尺寸同时受父对象缩放、模板缩放和 hair_length 影响。

配置示例中的数值是首版建模目标；素材定位点必须测量后填写。null 表示待标定，正式生成入口必须拒绝未标定数据，不能猜测果柄位置。

```json
{
  "seed": 0,
  "shape": {
    "height_m": 3.0,
    "crown_width_m": 3.6,
    "bare_trunk_height_m": 0.8,
    "trunk_diameter_m": 0.15,
    "main_branch_count": 4,
    "main_branch_elevation_deg": [10.0, 30.0],
    "internode_length_m": 0.12,
    "kill_distance_m": 0.20,
    "influence_range_m": 4.0,
    "endpoint_count": 800,
    "max_iterations": 200,
    "taper_power": 0.5,
    "tip_radius_m": 0.002
  },
  "leaves": {
    "length_m": [0.06, 0.12],
    "per_meter": 18.0,
    "max_branch_radius_m": 0.008,
    "distance_to_tip_m": 0.60,
    "tilt_random": 0.20,
    "assets": [{
      "id": "green_leaf",
      "image": "leaf_texture/green_leaves_PNG3638.png",
      "attach_uv": null,
      "tip_uv": null,
      "weight": 1.0
    }]
  },
  "fruits": {
    "diameter_m": [0.07, 0.09],
    "per_meter": 0.8,
    "branch_radius_m": [0.004, 0.020],
    "asset": {
      "obj": "fruit_model/apple_for_cycles.obj",
      "attach_point": null,
      "stem_axis": null,
      "body_diameter_points": null,
      "base_color": "fruit_model/Apple_Texture_by_AGF81.jpg",
      "normal_map": null
    }
  }
}
```

叶片的 attach_uv/tip_uv 采用左下角为原点的 UV 坐标；水果的点、轴采用导入后网格的本地坐标，body_diameter_points 是不包含果柄的两端测量点。不同素材各标定一次，之后可以用于任意树形和尺寸。这些数据只能放在资产配置里，算法里不能出现“如果文件名含 apple，就旋转90°”。

共享模块的最终接口（下列为接口说明，后面的代码块为拟实现的核心片段，尚不是完整可运行脚本）：

```text
load_settings(path, asset_root) -> dict  # 类型、有限值、范围、素材及标定数据校验
generate_tree(settings, asset_root, collection) -> dict
# 返回 trunk、leaf_emitter、fruit_emitter、templates、bounds、report
build_leaf_template(image, attach_uv, tip_uv) -> bpy.types.Object
build_fruit_template(asset, asset_root) -> bpy.types.Object
create_emitter(tree, region_name, collection) -> bpy.types.Object
configure_particles(emitter, prototype, count, size_range, seed, tilt_random)
visible_tree_bounds(scene, depsgraph) -> tuple
```

接口用普通字典和 Blender 原生数据，不引入新的框架或外部依赖。Blender 文本编辑器入口先沿用目前已修复的 BASE_DIR 获取方式，再把该目录加入模块搜索路径；开发期间修改共享模块后重新加载模块，配置每次运行都重新读取。

```python
import importlib
import json
import sys

if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))
import tree_geometry
importlib.reload(tree_geometry)

settings = tree_geometry.load_settings(BASE_DIR / 'tree_settings.json', BASE_DIR)
# 上述校验及插件能力检查全部通过后，才开始替换本次生成的对象。
result = tree_geometry.generate_tree(settings, BASE_DIR, generated_collection)
tree = result['trunk']
```

重新生成只替换带生成器标记的 GeneratedTree 集合内容，已有手工模型保留。首轮预览使用空场景；这个行为变化须写入 README 并加入检查，不能继续默认删除全部视图层对象。

**5. 骨架、生长与粗细的代码方法**

骨架使用同一份本地米制数据：points、parents、children、radii、trunk_nodes、distance_to_tip。节点的 generation 是生长过程数据，不直接当作解剖上的枝级。主干节点由构建主干链时标记，细枝由半径和通向末端的距离识别。

先用树高、裸干高度、主枝数量、主枝角度与随机种子生成主干链和主枝链。主枝方位近似均匀分开，再加有限扰动；所有长度由冠幅和配置派生。每个节点至多两个子节点，与现有 SCA 的二叉分枝约束一致，因此主枝从不同高度的主干节点分出。

SCA 新接口的关键变更如下。initial_skeleton 为 [(位置, 父索引), ...]，仅第一个节点父索引为 None，其余父索引必须小于本节点索引。此片段展示新增初始化逻辑，完整实现还须保留原有初始化、错误检查及旧 startingpoints 路径。

```python
# scanew.py：SCA.__init__ 末尾增加 initial_skeleton=None。
# 在 NENDPOINTS 的 addEndPoint 循环之前调用。
def initialize_skeleton(self, nodes):
    validate_skeleton(nodes)  # 单根、有限坐标、不重复位置、父索引合法、至多二子
    self.bp = array('d', (c for p, parent in nodes for c in p))
    self.bpp = [parent for p, parent in nodes]
    self.bpg = [0] * len(nodes)
    self.bpc = array('i', [0] * len(nodes))
    self.bpa = [0] * len(nodes)
    for parent in self.bpp:
        if parent is not None:
            self.bpc[parent] += 1
            self.bpa[parent] += 1
```

initial_skeleton 与旧 startingpoints 同时提供时拒绝；默认 None 保持旧调用行为。吸引点在目标树冠体积内采样，新生侧枝不能进入裸干区域。较短节间配合较小终止距离和足够迭代，增加末梢细节；这不等于把整条主枝缩短。

距离按 scanew.py 的实际实现传入：KILLDIST、INFLUENCE 是绝对长度。现插件提示“节间倍数”，但 execute 直接传递数值，没有乘 internodeLength。修正提示与 LENGTH 单位，保留旧数值语义，不悄悄改变老预设。

复用插件的 SCA 与 createGeometry，最终 Skin 修改器位于细分之前。BLENDER 模式关闭前置边细分，仅在 Skin 后使用一层细分作为基线；原生 NATIVE 模式的旧行为保留。

```python
# 使用已有插件核心生成；这里只列关键参数，volume/exclude 由共享模块构建。
growth = sca_module.SCA(
    NENDPOINTS=shape['endpoint_count'], NBP=shape['max_iterations'],
    d=shape['internode_length_m'], KILLDIST=shape['kill_distance_m'],
    INFLUENCE=shape['influence_range_m'], SEED=settings['seed'],
    volume=crown_volume, exclude=exclude_growth,
    initial_skeleton=scaffold,
)
growth.iterate()
tree = sca_module.createGeometry(
    growth, power=shape['taper_power'], scale=0.01,
    nomodifiers=False, skinmethod='BLENDER', subsurface=False,
    leafParticles='None', objectParticles='None',
)
# 随后按下面的米制半径覆盖 Skin 半径；0.01 只是插件旧接口的初始化值。
```

主干粗细不再取决于总顶点数量。以每个节点下游的枝条总长度作为承载权重；边上插入更多采样点不会改变总长度。

```python
downstream = [0.0] * len(points)
for i in reversed(topological_order):
    downstream[i] = sum(
        (points[j] - points[i]).length + downstream[j] for j in children[i]
    )
base_radius = shape['trunk_diameter_m'] / 2
if downstream[root] <= 0:
    raise ValueError('骨架没有可用枝条')
for i, skin_vertex in enumerate(tree.data.skin_vertices[0].data):
    r = max(shape['tip_radius_m'],
            base_radius * (downstream[i] / downstream[root]) ** shape['taper_power'])
    radii[i] = r
    skin_vertex.radius = (r, r)
```

Skin 半径不是最终细分截面的精确半径。应测量裸干中部的最终截面并做一次整体半径校准，再生成发射器；不能用包含全部树冠的物体包围盒测“主干直径”。若分叉出现 Skin 异常，灰模阶段定位该节点，不用叶片遮住它。

**6. 发射区域与数量**

叶片区域同时满足：不是主干节点、位于裸干之上、枝条半径不超过上限、沿枝条通往末端的距离不超过上限。水果使用独立的半径区间和区域规则，不共用叶片密度。

```python
leaf_ok = (
    i not in trunk_nodes
    and points[i].z >= shape['bare_trunk_height_m']
    and radii[i] <= leaves['max_branch_radius_m']
    and distance_to_tip[i] <= leaves['distance_to_tip_m']
)
leaf_region.add([i], 1.0 if leaf_ok else 0.0, 'REPLACE')
```

这里只显示区域判定核心。需遍历全部节点，使用树木本地坐标，不把世界 z 或固定顶点编号当作分类规则。

将区域组通过 Skin/细分传递到评估网格，create_emitter 只复制全部角点均处于该区域的面，并再次检查裸干高度。这样排除边界插值产生的低处发射；若无法取得评估后的权重，报错定位，不退回“全树发射”。从最终可见网格复制坐标，避免骨架中心线与平滑后的枝条表面不一致。

区域传递已用一个分叉灰模在本机隔离验证：评估后的1272个面中筛出392个末梢面，最低高度约1.58单位，低处主干没有进入选区。以下是拟放入 `tree_geometry.py` 的面提取核心；调用者还须复制 Density 权重、记录区域统计和零面情况。

```python
def extract_emitter(tree, group_name, min_height, collection, name):
    group = tree.vertex_groups.get(group_name)
    if group is None:
        raise ValueError(f'缺少区域组：{group_name}')
    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = tree.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
    try:
        def allowed(vertex):
            weight = next((g.weight for g in vertex.groups
                           if g.group == group.index), 0.0)
            return weight >= 0.999 and vertex.co.z >= min_height
        faces = [tuple(p.vertices) for p in mesh.polygons
                 if p.area > 1e-12 and all(allowed(mesh.vertices[i]) for i in p.vertices)]
        if not faces:
            return None
        old_ids = sorted({i for face in faces for i in face})
        remap = {old: new for new, old in enumerate(old_ids)}
        positions = [tuple(mesh.vertices[i].co) for i in old_ids]
        faces = [tuple(remap[i] for i in face) for face in faces]
    finally:
        evaluated.to_mesh_clear()
    emitter_mesh = bpy.data.meshes.new(name)
    emitter_mesh.from_pydata(positions, [], faces)
    emitter_mesh.update()
    emitter = bpy.data.objects.new(name, emitter_mesh)
    collection.objects.link(emitter)
    emitter.parent = tree
    emitter.matrix_parent_inverse = Matrix.Identity(4)
    emitter.matrix_basis = Matrix.Identity(4)
    emitter.show_instancer_for_viewport = False
    emitter.show_instancer_for_render = False
    return emitter
```

```python
# emitter 的网格已经只含合法枝条表面。
emitter.parent = tree
emitter.matrix_parent_inverse.identity()
emitter.show_instancer_for_viewport = False
emitter.show_instancer_for_render = False
# 不设置 hide_render=True，也不 hide_set(True)：否则粒子可能一起消失。
```

数量 N=round(每米密度×合法枝条总长度)，按资产权重分配到粒子系统，分配总和必须等于 N。各系统使用不同种子，例如 seed+100+资产序号。有效区域为零时数量为零，避免默认发射到主干。

粒子按面面积采样，会偏爱较粗枝条。因此发射器再设置 Density 权重，使用与半径成反比的相对权重，近似抵消表面积优势。长度定总量、Density 定分布，各司其职；它仍不是严格的逐节位叶序。

**7. 模板、尺寸和朝向**

叶片：以 alpha 的有效边界生成带 UV 的裁边平面，保持原贴图；用 attach_uv 平移叶柄基点到原点，用 tip_uv 校准有效长度到 1 单位。统一模板法线为本地 +X、叶柄到叶尖方向为本地 +Y。透明留白不参与有效尺寸计算，不修改原图片。

二维标定转换的核心如下；`uv_corners` 来自 alpha 有效边界，原 UV 写回生成的网格。此代码使用图片像素长宽处理长宽比，不依赖当前四张图片的具体分辨率。

```python
width, height = image.size
attach = Vector((attach_uv[0] * width, attach_uv[1] * height))
tip = Vector((tip_uv[0] * width, tip_uv[1] * height))
length = (tip - attach).length
if length <= 1e-6:
    raise ValueError('叶柄基点与叶尖不能重合')
forward = (tip - attach).normalized()
side = Vector((-forward.y, forward.x))
vertices = []
for u, v in uv_corners:
    q = Vector((u * width, v * height)) - attach
    vertices.append((0.0, q.dot(forward) / length, q.dot(side) / length))
# 构造保留原UV的平面：叶柄基点在0，叶尖在+Y，法线为+X。
```

水果：收集本次 OBJ 导入的新网格，不能只猜导入后的活动对象名。保留 UV 与材质；以 attach_point 为原点，以 body_diameter_points 把果身直径烘焙为 1 单位；stem_axis 对齐本地 +X，果身位于负 X 方向。之后粒子 +X 朝上，水果就朝下悬挂。资产有多个部件时先合并新导入部件，不能吞入用户原有对象。

这两个模板约定与 Blender 的粒子 X 轴朝向规则配合。当前平面素材只作临时验证时可绕 Y 转90°；正式算法应统一模板坐标，不给每个新素材试凑旋转。[Blender 粒子旋转说明](https://docs.blender.org/UATEST/manual/en/4.5/physics/particles/emitter/rotation.html)，实际字段与效果已在本机 Blender 5.2.1 测试。

```python
system = emitter.modifiers.new('Leaves', type='PARTICLE_SYSTEM').particle_system
system.seed = seed
system.vertex_group_density = 'Density'
p = system.settings
p.type = 'HAIR'
p.use_advanced_hair = True
p.hair_length = 1.0
p.emit_from = 'FACE'
p.use_even_distribution = True
p.use_emit_random = True
p.distribution = 'RAND'
p.use_modifier_stack = True
p.count = count
p.render_type = 'OBJECT'
p.instance_object = normalized_template
p.use_scale_instance = False
p.use_rotation_instance = True
p.use_rotations = True
p.rotation_mode = 'GLOB_Z'
p.phase_factor_random = 2.0
p.rotation_factor_random = tilt_random
p.particle_size = size_range[1]
p.size_random = 1.0 - size_range[0] / size_range[1]
```

模板几何烘焙为有效尺寸1后，particle_size 才能表示最终米制长度/果径。size_random 的结果是从最大尺寸向下缩小，不是对称的正负变化。叶、果参数独立，水果倾斜幅度更小。叶片的 tilt_random 是 Blender 随机旋转系数，不是角度；通过实例矩阵统计倾角，不把 0.2 标成20°。

替换当前叶片 Soft Body 设置：基线使用稳定静态模板。枝条与叶片的轻微弯曲在模板中处理，避免逐帧软体变化破坏挂接；风与物理摆动不属于这轮结构修复。

**8. 材质、标签、相机和可复现**

- 叶片恢复自然颜色，保留透明遮罩，凹凸距离按厘米尺寸设置为毫米量级；不再强制饱和度为0。
- 苹果颜色贴图只接 Base Color。normal_map 为 null 时不创建 NormalMap，不能把颜色图当作切线法线。水果几何位移按目标果径比例限制，基线先取消原来的强 CLOUDS 位移。
- Skin 网格未必有 UV。树皮使用明确的 Object 坐标与米制纹理尺度；不能让依赖 UV 的贴图在全零坐标上采样。
- 主干、叶片、果实材料仍分别标为1、2、3，发射器表面不渲染。按本次实际模板及导入的所有材质赋值，不再引用四个固定对象名字。
- 分割可视化不能逐帧 Normalize 材质索引，否则某类暂时不可见时颜色会变化。用固定除以3的映射接现有颜色表；检查没有水果的画面中叶片仍保持叶片类别。
- 深度、法线沿用现有可视化含义；不把当前归一化深度称为米制深度。
- 相机根据可见树体及粒子实例的包围球取景，半径 R、视角 alpha 下距离 d>=margin*R/sin(alpha/2)，取横纵视角较小者并留边。读取实例时立即复制 matrix_world/bound_box，不能保存迭代器的 RNA 引用。
- 相机使用 random.Random(seed+10000)，不依赖 SCA 内部使用的全局随机源。树形不变只改相机种子，或只改叶片参数，结果互不串扰。
- 本次运行保存实际配置、模板标定、种子与生成统计到输出目录。换机器使用相对路径与随包素材，不能写入本机盘符/用户名。

**9. 验收与实施顺序**

| 阶段 | 交付 | 检查重点 |
|---|---|---|
| A：骨架与灰模 | 共享配置、可选主干主枝初始骨架、连续 Skin 网格；三个角度灰模 | 主干清楚、主枝开展、侧枝有延伸与末梢细枝；只有一个根、无断开骨架 |
| B：少量挂叶和挂果 | 校准模板、LeafEmitter/FruitEmitter、低密度粒子；局部近景与角度统计 | 叶柄/果柄原点落在发射枝条上，主干下部无发射，大小与低倾角符合配置 |
| C：完整树冠与输出 | 按长度密度生成全部实例、材质、相机与标签 | 三个角度看整体比例，类别不漂移，主体不被取景截断 |
| D：复用检查 | 多配置结果和自动检查报告 | seed=0/1/7，树高2.5/3.5/4.5米；至少两种叶片和苹果/橙子素材；改变尺寸后数量随长度改变 |

自动检查：骨架父索引合法且连通；Skin半径随分枝不异常增大；发射器没有粗干区域；实例挂接原点到合法发射面的误差在毫米容差内；测量有效叶身/果身而非图片空白；同配置同种子结果可重复；角度分布以配置目标区间验收；相机覆盖包围体；材质类别与实际像素输出一致。

复用还需验证：给同一骨架边插入采样点，主干半径不应因为顶点增多而改变；移动树木后挂接与取景跟随；素材模板烘焙前带不同缩放/原点时，最终尺寸仍与配置一致；缺素材、未标定定位点或插件缺能力时在替换场景前报错。

插件接口若增加 initial_skeleton，必须同步工作区源码、新版本安装 ZIP、使用说明和 portable_plugin_smoke.py；保留0.2.16原包。新版在临时目录和空白 Blender 中验证后，再由用户安装到正在使用的 Blender。不能只改工作区源码就宣称已安装插件也更新。

本蓝图的角度、尺寸机制和区域权重传递已做隔离测试；新增骨架接口、真实素材模板标定与整体管线尚未实施。粒子方案能控制合法区域、尺寸和朝向，但不保证严格的交替叶序、叶片之间完全不穿插或受力正确。若后续要求逐节位叶序，可将发射环节换成骨架节点实例化，并复用本蓝图的配置、骨架和模板接口。
