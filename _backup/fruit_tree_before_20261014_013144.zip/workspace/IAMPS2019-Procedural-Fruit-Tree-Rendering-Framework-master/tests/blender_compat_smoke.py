"""Run with Blender --background --factory-startup --python this_file.py."""
import ast
import importlib
import struct
import sys
import tempfile
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
CHECKS = ROOT.parent / '_compat_check'
CHECKS.mkdir(exist_ok=True)
OUTPUT = Path(tempfile.mkdtemp(prefix='blender_5_2_', dir=CHECKS))

# Exercise Blender's actual Run Script operator, whose __file__ is virtual.
window = bpy.context.window
area = window.screen.areas[0]
previous_type = area.type
area.type = 'TEXT_EDITOR'
region = next(region for region in area.regions if region.type == 'WINDOW')
for filename in ['sapling_tree_scene_gen.py', 'space_tree_scene_gen.py', 'rendering_loop.py']:
    path = ROOT / filename
    prelude = []
    for node in ast.parse(path.read_text(encoding='utf-8')).body:
        prelude.append(node)
        if isinstance(node, ast.Assign) and ast.unparse(node.targets[0]) == 'BASE_DIR':
            break
    text = bpy.data.texts.new(filename)
    text.filepath = str(path)
    code = ast.unparse(ast.Module(prelude, type_ignores=[]))
    text.write(code + f'\nassert BASE_DIR == Path({str(ROOT)!r})\n')
    area.spaces.active.text = text
    with bpy.context.temp_override(window=window, area=area, region=region):
        assert bpy.ops.text.run_script() == {'FINISHED'}
    bpy.data.texts.remove(text)
area.type = previous_type
print('PASS text_editor_paths', flush=True)

addons = Path(bpy.utils.user_resource('SCRIPTS')) / 'addons'
extensions = Path(bpy.utils.user_resource('EXTENSIONS')) / 'blender_org'
sys.path[:0] = [str(addons), str(extensions)]

sca = importlib.import_module('add_mesh_space_tree')
sca.register()
importlib.import_module('sapling_tree_gen').register()

library = str(addons / 'add_mesh_space_tree/material_lib.blend')
materials_a = sca.load_materials_from_bundled_lib('add_mesh_space_tree', 'material_lib.blend', 'Bark')
materials_b = sca.load_materials_from_bundled_lib('add_mesh_space_tree', 'material_lib.blend', 'Bark')
presets_a = sca.load_particlesettings_from_bundled_lib('add_mesh_space_tree', 'material_lib.blend', 'LeafEmitter')
presets_b = sca.load_particlesettings_from_bundled_lib('add_mesh_space_tree', 'material_lib.blend', 'LeafEmitter')
assert materials_a.keys() == materials_b.keys()
assert presets_a.keys() == presets_b.keys()
assert all(isinstance(name, str) for name in [*materials_a, *presets_a])


class SmallRender(ast.NodeTransformer):
    def __init__(self, folder, fruit):
        self.folder = folder
        self.fruit = fruit

    def visit_Assign(self, node):
        target = ast.unparse(node.targets[0])
        if target in {'scene.render.resolution_x', 'scene.render.resolution_y'}:
            node.value = ast.Constant(64)
        elif target == 'scene.cycles.samples':
            node.value = ast.Constant(2)
        elif target == 'starting_frame_num':
            node.value = ast.Constant(3)
        elif target == 'ending_frame_num':
            node.value = ast.Constant(4)
        elif target == 'change_frequency':
            node.value = ast.Constant(1)
        elif target == 'fruit_type':
            node.value = ast.Constant(self.fruit)
        elif target == 'output_folder':
            node.value = ast.Call(ast.Name('Path', ast.Load()), [ast.Constant(str(self.folder / 'images'))], [])
        elif target == 'node.directory':
            leaf = ast.literal_eval(node.value.args[0].right).split('/')[-1]
            node.value = ast.Constant(str(self.folder / leaf))
        return self.generic_visit(node)

    def visit_Call(self, node):
        if ast.unparse(node.func) == 'bpy.ops.mesh.sca_tree':
            for keyword in node.keywords:
                if keyword.arg == 'numberOfEndpoints':
                    keyword.value = ast.Constant(100)
                elif keyword.arg == 'maxIterations':
                    keyword.value = ast.Constant(40)
        return self.generic_visit(node)


def run_script(filename, folder, fruit='a'):
    path = ROOT / filename
    tree = SmallRender(folder, fruit).visit(ast.parse(path.read_text(encoding='utf-8')))
    tree = ast.fix_missing_locations(tree)
    exec(compile(tree, str(path), 'exec'), {'__file__': str(path), '__name__': '__main__'})


# Missing plugins must fail before the generation script clears the user's scene.
sca.unregister()
before = set(bpy.context.scene.objects)
try:
    run_script('space_tree_scene_gen.py', OUTPUT / 'missing_plugin')
except RuntimeError as error:
    assert 'Enable SCA' in str(error)
else:
    raise AssertionError('Missing SCA plugin must stop scene generation')
assert set(bpy.context.scene.objects) == before
sca.register()

# Collection volumes and the modern ray_cast signature must work on transformed meshes.
bpy.ops.mesh.primitive_cube_add(location=(2, 0, 0))
cube = bpy.context.object
cube.scale = (2, 1, 1)
cube.rotation_euler.z = 0.4
bpy.context.view_layer.update()
assert sca.pointInsideMesh(Vector((2, 0, 0)), cube)
assert not sca.pointInsideMesh(Vector((20, 0, 0)), cube)

other_scene = bpy.data.scenes.new('Preserve Other Scene')
shared = bpy.data.objects.new('Shared Object', cube.data.copy())
bpy.context.scene.collection.objects.link(shared)
other_scene.collection.objects.link(shared)
bpy.context.view_layer.update()

for case, script, fruit in [
    ('sapling', 'sapling_tree_scene_gen.py', 'o'),
    ('space_apple', 'space_tree_scene_gen.py', 'a'),
    ('space_orange', 'space_tree_scene_gen.py', 'o'),
]:
    folder = OUTPUT / case
    bpy.context.scene.name = 'Compatibility Test'
    run_script(script, folder, fruit)
    assert shared.name in other_scene.objects
    assert shared.name not in bpy.context.scene.objects
    assert bpy.context.scene.camera is not None
    if script.startswith('space'):
        systems = {modifier.name: modifier.particle_system.settings
                   for modifier in bpy.data.objects['Tree'].modifiers
                   if modifier.type == 'PARTICLE_SYSTEM'}
        assert len(systems) == 6
        assert systems['Apples'].count == (100 if fruit == 'a' else 0)
        assert systems['Oranges'].count == (100 if fruit == 'o' else 0)
        assert all(material.pass_index == 3 for material in bpy.data.objects['Apple'].data.materials)
        assert all(material.pass_index == 1 for material in bpy.data.objects['Tree'].data.materials)
    run_script('rendering_loop.py', folder)
    expected = ['images']
    if script.startswith('space'):
        expected += ['depth_map', 'normal_map', 'segmentation_map']
    for output_type in expected:
        files = sorted((folder / output_type).glob('*.png'))
        assert len(files) == 2, (case, output_type, files)
        if output_type != 'images':
            assert {file.name for file in files} == {'Image0003.png', 'Image0004.png'}
        for file in files:
            header = file.read_bytes()[:24]
            assert header[:8] == b'\x89PNG\r\n\x1a\n'
            assert struct.unpack('>II', header[16:24]) == (64, 64)
    image = bpy.data.images.load(str(folder / 'images/image_3.png'))
    pixels = list(image.pixels)[0::4]
    assert max(pixels) - min(pixels) > 0.01, 'Rendered image must contain visible variation'
    print('PASS', case, flush=True)

sca.unregister()
sca.register()
assert bpy.ops.mesh.sca_tree.get_rna_type().identifier == 'MESH_OT_sca_tree'
print('ALL COMPATIBILITY CHECKS PASSED', OUTPUT, flush=True)
