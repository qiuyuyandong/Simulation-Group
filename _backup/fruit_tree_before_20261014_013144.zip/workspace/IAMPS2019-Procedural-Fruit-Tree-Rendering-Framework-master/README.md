# IAMPS2019-Procedural-Fruit-Tree-Rendering-Framework

## 本地 Blender 5.2.1 适配版

- `sapling_tree_scene_gen.py`：Sapling 果树场景；先启用 Sapling Tree Gen。
- `space_tree_scene_gen.py`：SCA 果树场景及深度、法线、分割可视化；先启用修复后的 SCA Tree Generator。
- `rendering_loop.py`：在上述任一场景中批量渲染图片。
- 在 Blender 的 Scripting 工作区打开磁盘上的 `.py` 文件并运行，素材路径以该文件目录为基准。
- 已经打开的脚本在磁盘上更新后，通过文本编辑器的“文本 → 重新加载”读取新版再运行。
- 场景生成会删除当前视图层的对象，请先保存已有工作。渲染默认 5000 张，首次使用建议将 `ending_frame_num` 改为 `2`，确认输出后再增加。
- 图片保存在 `output/images`；SCA 的三类标注分别保存在 `depth_map`、`normal_map`、`segmentation_map`，文件带帧编号。同名输出仍会覆盖。
- 标注沿用原来的归一化和彩色可视化处理；深度图不是以米为单位的原始深度数据。
- 原始脚本和插件备份位于工作区 `_backup/blender2_original_20261013.zip`。
- `tests/blender_compat_smoke.py` 在独立目录生成 64×64 测试图，检查两种果实、标注编号及跨场景对象保护。

Code to accompany the IAMPS 2019 paper "Toward a procedural fruit tree rendering framework for image analysis"

Source code authors : Thomas Duboudin, Maxime Petit, Sridhar Ragupathi, Liming Chen

This code allows you to reproduce the results of the IAMPS 2019 paper "Toward a procedural fruit tree rendering framework for image analysis".

## Original installation instructions (Blender 2.x)

(On Ubuntu 18.04)

1 - Download and install Blender (https://www.blender.org/). We are aware of problems with the gpu-rendering options on Blender 2.79b, thus, by default, it's the CPU rendering that is enabled. It's possible to switch the option to GPU in the scene generation scripts, at the end of each of the scripts. To enable GPU-rendering, follow this link : https://docs.blender.org/manual/en/dev/render/cycles/gpu_rendering.html.

2 - Install the Blender Add-on "Sapling Tree Gen". To do so, go to "File" -> "User preferences" -> "Add-ons" and search for "Sapling Tree Gen" in the research toolbar. Click on the tick-box and save the setting at the bottom of the window.

3 - Install the "spacetree" Add-on, to do so : go to https://github.com/varkenvarken/spacetree and follow the installation instructions. It's an older Add-on no longer by default on Blender, you'll need to download a zip file and import it in Blender.

4 - (if needed) Download the textures and additional files from the following links and put them in the corresponding folder. There is already a few files for a plug-and-play example :

-- HDRIs (360° high-resolution background image) : https://hdrihaven.com/

-- Leaves textures : http://pngimg.com/, https://www.textures.com/

-- Bark texture : https://www.textures.com/

-- Fruit 3D models & texture : https://www.turbosquid.com/, https://free3d.com/3d-models/

5 - Clone the repository.

6 - Open the Blender GUI and choose the "Scripting" panel configuration (in the top toolbar, next to "Help", it should be at default initially).

7 - Open the scene generation script and launch it.

8 - Open the rendering script and launch it.

## Some examples of generated images

![](example_images/random_images.png?raw=true "Random Images")

### Random Images

![](example_images/real_vs_fake.png?raw=true "Real (top row) vs Fake (bottow row) Images")

### Real (bottow row) vs Fake (top row) Images

![](example_images/variations.png?raw=true "Variations in Images (day/night, backround, pow)")

### Variations in Images (day/night, backround, pow)


## Comments 

==> You can change the rendering parameters and the scene parameters in the corresponding scripts. In particular, if you're designing a new tree model, don't forget to change the camera movement parameters (the inner box for the empty element and the outer cylinder for the camera).

==> If you're needing more blender knowledge, check the tutorials by Blender Guru. We believe at least some low level of knowledge is required to be able to use and modify the scripts, in particular to understand some of the Blender API functions.

==> We cannot easily make sure that the leaves are attached to the branches by their tails, nor that there won't be fruits and leaves intersecting themselves. This is linked to the fruits and leaves generation as random particles on the tree structure. We do not believe it is going to be a major issue with our data, since complete photorealism does not seem to be needed (cf paper) for deep learning. Besides, there is a trade-off between the time spent designing a model and the amout of variations we can put in the rendered images.

==> The two scene generation scripts are using a different Blender Add-on. There are more options and customizations available in the space_tree_scene_gen.py script (such as different kinds of leaves on the same tree, slightly differents fruits).

## Acknowledgements

This work is supported by the french National Research Agency (ANR), through the ARES labcom (grant ANR 16-LCV2-0012-01) and by the CHIST-ERA EU project "Learn-Real".

## Credits

The given HRDI : https://hdrihaven.com/hdri/?c=outdoor&h=spruit_sunrise

The given leaves textures : https://www.textures.com/download/leaves0089/21795?q=leaves, http://pngimg.com/download/3668, http://pngimg.com/download/3638, http://pngimg.com/download/3581, http://pngimg.com/download/3609

The given bark texture : https://www.textures.com/download/3dscans0062/127610?q=cedar+tree

The given orange object : https://www.turbosquid.com/3d-models/free-3ds-model-orange-resolution-photorealistic/756550

The given apple object : https://free3d.com/3d-model/apples-42451.html





